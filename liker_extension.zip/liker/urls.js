export const urls = {
  createUser: "https://chrome.likemeplease.com/users/create",
  addLinks: "https://chrome.likemeplease.com/links/addLinks",
  notLikedLinks: "https://chrome.likemeplease.com/links/notLikedLinks",
  likeLinks: "https://chrome.likemeplease.com/links/likeLinks",
};
